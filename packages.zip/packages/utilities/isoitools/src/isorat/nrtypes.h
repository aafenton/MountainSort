// $Id: nrtypes.h,v 1.1 2008/03/19 15:19:32 samn Exp $ 
#include "nrtypes_nr.h"

//#include "nrtypes_lib.h"
