mex ./_mcwrap/mcwrap_isosplit5_mex.cpp ./isosplit5.cpp ./isocut5.cpp ./jisotonic5.cpp -output ./isosplit5_mex 
